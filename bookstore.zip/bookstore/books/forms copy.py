from django import forms
from django.forms import fields, widgets
from .models import User, Review, Comment


# class SignupForm(forms.ModelForm):
#     class Meta:
#         model = User
#         fields = ["nickname"]

#     def signup(self, request, user):
#         user.nickname = self.cleaned_data["nickname"]
#         user.save()


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = [
            "title",
            "book_name",
            "rating",
            "image1",
            "content",
        ]
        widgets = {
            "rating": forms.RadioSelect,
        }


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = [
            "nickname",
            "profile_pic",
            "intro",
        ]
        widgets = {
            "intro": forms.Textarea,
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = [
		    'content',
        ]
        widget = {
		    'content':forms.Textarea
	    }