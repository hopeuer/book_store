from django.urls import path
from . import views
 
urlpatterns = [
  path('', views.index, name="index"),
  path('GET/api/books', views.PostListView.as_view(), name='post-list'),
  path('POST/api/books', views.PostCreateView.as_view(), name="post-create"),
  path('posts/<int:pk>/', views.PostDetailView.as_view(), name='post-detail'),
  path('posts/<int:pk>/edit', views.PostUpdateView.as_view(), name="post-update"),
  path('posts/<int:post_id>/delete', views.PostDeleteView.as_view(), name="post-delete"),
]