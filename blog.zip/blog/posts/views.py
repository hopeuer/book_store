from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator
from django.views.generic import CreateView, ListView, DetailView, UpdateView, DeleteView
from django.urls import reverse
from .models import Post
from .forms import PostForm

# 수정 부분
class PostUpdateView(UpdateView):
      model = Post
      form_class = PostForm
      
      def get_success_url(self):
          return reverse('post-detail', kwargs={'pk':self.object.id})
        
        
class PostDetailView(DetailView):
      model = Post
      
      
# 생성 부분
class PostCreateView(CreateView):
        model = Post
        form_class = PostForm
        
        def get_success_url(self):
            return reverse('post-detail', kwargs={'pk':self.object.id})
  
# 목록 부분
class PostListView(ListView):
      model = Post
      ordering = ['-dt_created']
      paginate_by = 9
      
   
# 삭제 부분
class PostDeleteView(DeleteView):
      model = Post
      template_name = 'posts/post_delete.html'
      pk_url_kwarg = 'post_id'
      context_object_name = 'post' 
    
      def get_success_url(self):
          return reverse('post-list')
        
      
def index(request):
    return redirect('post-list')
  

